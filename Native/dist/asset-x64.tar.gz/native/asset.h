#pragma once

#ifdef __cplusplus
extern "C" {
#endif

double depreciation(int life, int after);

#ifdef __cplusplus
}
#endif

